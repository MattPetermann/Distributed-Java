package us.mattgreen.thanks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThanksApplication {

    public static void main(String[] args) {
        SpringApplication.run(ThanksApplication.class, args);
    }
}
