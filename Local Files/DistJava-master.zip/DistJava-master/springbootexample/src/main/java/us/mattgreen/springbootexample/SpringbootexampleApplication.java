package us.mattgreen.springbootexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootexampleApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootexampleApplication.class, args);
    }
}